/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.pnb.fd.service.service.impl;

import com.liferay.counter.kernel.service.CounterLocalServiceUtil;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.util.ParamUtil;
import com.pnb.fd.service.model.Form;
import com.pnb.fd.service.service.FormLocalServiceUtil;
import com.pnb.fd.service.service.base.FormLocalServiceBaseImpl;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;

/**
 * @author Brian Wing Shun Chan
 */
@Component(
	property = "model.class.name=com.pnb.fd.service.model.Form",
	service = AopService.class
)
public class FormLocalServiceImpl extends FormLocalServiceBaseImpl {
	
	/*
	 * public static void addFormDetails(ResourceRequest resourceRequest,
	 * ResourceResponse resourceResponse) {
	 * System.out.println("FormLocalServiceImpl.addFormDetails()");
	 * 
	 * String name = ParamUtil.getString(resourceRequest, "name"); String mobileno =
	 * ParamUtil.getString(resourceRequest, "mobileno"); String email =
	 * ParamUtil.getString(resourceRequest, "email"); String location =
	 * ParamUtil.getString(resourceRequest, "location"); String amount =
	 * ParamUtil.getString(resourceRequest, "amount");
	 * 
	 * Long applicantId = CounterLocalServiceUtil.increment(); Form form =
	 * FormLocalServiceUtil.createForm(applicantId); form.setFullname(name);
	 * form.setMobile(mobileno); form.setEmail(email); form.setLocation(location);
	 * form.setAmount(amount);
	 * 
	 * 
	 * System.out.println("FormLocalServiceImpl.end"); }
	 */
		
}