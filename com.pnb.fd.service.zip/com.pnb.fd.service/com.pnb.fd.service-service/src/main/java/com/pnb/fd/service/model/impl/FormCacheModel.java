/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.pnb.fd.service.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import com.pnb.fd.service.model.Form;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Form in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class FormCacheModel implements CacheModel<Form>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof FormCacheModel)) {
			return false;
		}

		FormCacheModel formCacheModel = (FormCacheModel)object;

		if (applicantId == formCacheModel.applicantId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, applicantId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(15);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", applicantId=");
		sb.append(applicantId);
		sb.append(", fullname=");
		sb.append(fullname);
		sb.append(", mobile=");
		sb.append(mobile);
		sb.append(", email=");
		sb.append(email);
		sb.append(", location=");
		sb.append(location);
		sb.append(", amount=");
		sb.append(amount);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Form toEntityModel() {
		FormImpl formImpl = new FormImpl();

		if (uuid == null) {
			formImpl.setUuid("");
		}
		else {
			formImpl.setUuid(uuid);
		}

		formImpl.setApplicantId(applicantId);

		if (fullname == null) {
			formImpl.setFullname("");
		}
		else {
			formImpl.setFullname(fullname);
		}

		if (mobile == null) {
			formImpl.setMobile("");
		}
		else {
			formImpl.setMobile(mobile);
		}

		if (email == null) {
			formImpl.setEmail("");
		}
		else {
			formImpl.setEmail(email);
		}

		if (location == null) {
			formImpl.setLocation("");
		}
		else {
			formImpl.setLocation(location);
		}

		if (amount == null) {
			formImpl.setAmount("");
		}
		else {
			formImpl.setAmount(amount);
		}

		formImpl.resetOriginalValues();

		return formImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();

		applicantId = objectInput.readLong();
		fullname = objectInput.readUTF();
		mobile = objectInput.readUTF();
		email = objectInput.readUTF();
		location = objectInput.readUTF();
		amount = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(applicantId);

		if (fullname == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(fullname);
		}

		if (mobile == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(mobile);
		}

		if (email == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(email);
		}

		if (location == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(location);
		}

		if (amount == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(amount);
		}
	}

	public String uuid;
	public long applicantId;
	public String fullname;
	public String mobile;
	public String email;
	public String location;
	public String amount;

}