create table FD_Form (
	uuid_ VARCHAR(75) null,
	applicantId LONG not null primary key,
	fullname VARCHAR(75) null,
	mobile VARCHAR(75) null,
	email VARCHAR(75) null,
	location VARCHAR(75) null,
	amount VARCHAR(75) null
);