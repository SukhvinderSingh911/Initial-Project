/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.pnb.fd.service.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Form}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Form
 * @generated
 */
public class FormWrapper
	extends BaseModelWrapper<Form> implements Form, ModelWrapper<Form> {

	public FormWrapper(Form form) {
		super(form);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("applicantId", getApplicantId());
		attributes.put("fullname", getFullname());
		attributes.put("mobile", getMobile());
		attributes.put("email", getEmail());
		attributes.put("location", getLocation());
		attributes.put("amount", getAmount());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long applicantId = (Long)attributes.get("applicantId");

		if (applicantId != null) {
			setApplicantId(applicantId);
		}

		String fullname = (String)attributes.get("fullname");

		if (fullname != null) {
			setFullname(fullname);
		}

		String mobile = (String)attributes.get("mobile");

		if (mobile != null) {
			setMobile(mobile);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String location = (String)attributes.get("location");

		if (location != null) {
			setLocation(location);
		}

		String amount = (String)attributes.get("amount");

		if (amount != null) {
			setAmount(amount);
		}
	}

	@Override
	public Form cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the amount of this form.
	 *
	 * @return the amount of this form
	 */
	@Override
	public String getAmount() {
		return model.getAmount();
	}

	/**
	 * Returns the applicant ID of this form.
	 *
	 * @return the applicant ID of this form
	 */
	@Override
	public long getApplicantId() {
		return model.getApplicantId();
	}

	/**
	 * Returns the email of this form.
	 *
	 * @return the email of this form
	 */
	@Override
	public String getEmail() {
		return model.getEmail();
	}

	/**
	 * Returns the fullname of this form.
	 *
	 * @return the fullname of this form
	 */
	@Override
	public String getFullname() {
		return model.getFullname();
	}

	/**
	 * Returns the location of this form.
	 *
	 * @return the location of this form
	 */
	@Override
	public String getLocation() {
		return model.getLocation();
	}

	/**
	 * Returns the mobile of this form.
	 *
	 * @return the mobile of this form
	 */
	@Override
	public String getMobile() {
		return model.getMobile();
	}

	/**
	 * Returns the primary key of this form.
	 *
	 * @return the primary key of this form
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the uuid of this form.
	 *
	 * @return the uuid of this form
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the amount of this form.
	 *
	 * @param amount the amount of this form
	 */
	@Override
	public void setAmount(String amount) {
		model.setAmount(amount);
	}

	/**
	 * Sets the applicant ID of this form.
	 *
	 * @param applicantId the applicant ID of this form
	 */
	@Override
	public void setApplicantId(long applicantId) {
		model.setApplicantId(applicantId);
	}

	/**
	 * Sets the email of this form.
	 *
	 * @param email the email of this form
	 */
	@Override
	public void setEmail(String email) {
		model.setEmail(email);
	}

	/**
	 * Sets the fullname of this form.
	 *
	 * @param fullname the fullname of this form
	 */
	@Override
	public void setFullname(String fullname) {
		model.setFullname(fullname);
	}

	/**
	 * Sets the location of this form.
	 *
	 * @param location the location of this form
	 */
	@Override
	public void setLocation(String location) {
		model.setLocation(location);
	}

	/**
	 * Sets the mobile of this form.
	 *
	 * @param mobile the mobile of this form
	 */
	@Override
	public void setMobile(String mobile) {
		model.setMobile(mobile);
	}

	/**
	 * Sets the primary key of this form.
	 *
	 * @param primaryKey the primary key of this form
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the uuid of this form.
	 *
	 * @param uuid the uuid of this form
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	protected FormWrapper wrap(Form form) {
		return new FormWrapper(form);
	}

}